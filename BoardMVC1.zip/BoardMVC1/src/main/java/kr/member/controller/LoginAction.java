package kr.member.controller;

public class LoginAction {

}
